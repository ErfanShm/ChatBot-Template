
      export const ChatTitle = "YOUR_DATA";
      export const FooterAreaTitle = "YOUR_DATA";
      export const PagebarTitle = "YOUR_DATA";

      export const AIChatBotName = "YOUR_DATA";
      export const UserName = "YOUR_DATA";

      export const Avatar_User_Path = "YOUR_DATA";
      export const Avatar_AI_Path = "YOUR_DATA";

      export const Button_Send_BackgroundColor = 'YOUR_DATA';
      export const Button_Send_Color = 'YOUR_DATA';
      export const Button_Send_Text = 'YOUR_DATA';

      export const Models = "gpt-3.5-turbo | gpt-4o-mini | gpt-4o | gpt-4-trubo | dall-e-2 | dall-e-3";

      export const faviconUrl = "YOUR_DATA";

      export const ConnectionFailed = 'Opps!!! :)';

      export const Footer_Section_TextColor = '#2c448c';
      export const Footer_Section_BackgroundColor = '1';

      export const baseUrl = "https://api.avalai.ir/v1";
      export const apiUrl = "https://api.avalai.ir/v1/images/generations";
      export const apiKey = "1";

      export const messages = [
            { role: "system", content: "You are a helpful assistant." }
        ];