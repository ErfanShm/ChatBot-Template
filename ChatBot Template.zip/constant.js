
      export const ChatTitle = "1";
      export const FooterAreaTitle = "11";
      export const PagebarTitle = "11";

      export const AIChatBotName = "11";
      export const UserName = "11";

      export const Avatar_User_Path = "1";
      export const Avatar_AI_Path = "1";

      export const Button_Send_BackgroundColor = '#000000';
      export const Button_Send_Color = '#000000';
      export const Button_Send_Text = '1';

      export const Models = "gpt-3.5-turbo | gpt-4o-mini | gpt-4o | gpt-4-trubo | dall-e-2 | dall-e-3";

      export const faviconUrl = "1";

      export const ConnectionFailed = 'Opps!!! :)';

      export const Footer_Section_TextColor = '#000000';
      export const Footer_Section_BackgroundColor = '#000000';

      export const baseUrl = "https://api.avalai.ir/v1";
      export const apiUrl = "https://api.avalai.ir/v1/images/generations";
      export const apiKey = "aa-crDGvdxPbJsFNth9WgEWdfAKSVFc6mX38bJZJkdzVSunsZ2A";
      export const messages = [
            { role: "system", content: "you are help assisant" }
        ];